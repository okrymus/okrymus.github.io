
# coding: utf-8

# In[512]:


# Import python modules
import numpy as np
import kaggle
import matplotlib.pyplot as plt

from math import sin
from math import cos
import math
from sklearn.linear_model import Ridge
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

############################################################################
# Read in train and test credit card data
def read_creditcard_data():
	print('Reading credit card data ...')
	train_x = np.loadtxt('../../Data/CreditCard/data_train.txt', delimiter = ',', dtype=float)
	train_y = np.loadtxt('../../Data/CreditCard/label_train.txt', delimiter = ',', dtype=float)
	test_x = np.loadtxt('../../Data/CreditCard/data_test.txt', delimiter = ',', dtype=float)

	return (train_x, train_y, test_x)

############################################################################
# Compute MSE
def compute_MSE(y, y_hat):
	# mean squared error
	return np.mean(np.power(y - y_hat, 2))

############################################################################

# In[513]:


class KRRS(object):
    def __init__(self, lmbda=0.1, sigma=0.5, kernel="poly", order_i = 1):
        self.lmbda = lmbda
        self.sigma = sigma
        self.i = order_i
        if (kernel == "poly"):
            self.kernel = self.kernelPoly
        else:
            self.kernel = self.kernelTrigo

    def fit(self, X, Y):
        self.trainX = X
        k_arr = np.zeros((X.shape[0], X.shape[0]))    # NxN

        for i in range(0, X.shape[0]):
            for j in range(0, X.shape[0]):
                x_i = X[i]
                x_j = X[j]
                kij =  self.kernel(x_i, x_j)  #call kernel fn
                k_arr[i][j] = kij
        #get
        lambda_dot_i = self.lmbda*np.identity(X.shape[0], dtype=np.float)
        #alpha = ((Phi(X)*phi^T(X)+lambda*I)^-1)*Y
        self.alpha = np.dot(np.linalg.inv(np.add(k_arr, lambda_dot_i)), Y)

    def predict(self, X):
        Y = np.zeros((X.shape[0]))        #zeros the matrix Y
        for test_index in range(0, X.shape[0]):
            x_new = X[test_index]
            Y[test_index] = np.sum([np.dot(self.alpha[i],  self.kernel(self.trainX[i], x_new)) for i in range(0, self.trainX.shape[0])])
        return Y

    def get_params(self, deep=True):
        if self.kernel == self.kernelPoly:
            kernel = "poly"
        else:
            kernel = "trigo"
        return {"lmbda": self.lmbda, "sigma": self.sigma, "kernel": kernel, "order_i": self.i }

    def set_params(self, lmbda=0.1):
        self.lmbda = lmbda
        return self

    def kernelPoly(self,x_1, x_2):
        #polynominal function
        #k(x_1,x_2) = (1+x_1*x_2) ^i

        return pow((1 + np.dot(x_1, x_2)), self.i)

    def kernelTrigo(self, x_1, x_2):
        #Trigonometric function
        #k(x_1; x_2) = 1  + sum((sin(k*δ*x_1) × sin(k*δ*x_2) + cos(k*δ*x_1) × cos(k*δ*x_2))) k =1 to i

        sigma = self.sigma
        return 1 + np.sum([np.dot(sin(k*sigma*x_1), sin(k*sigma*x_2)) + np.dot(cos(k*sigma*x_1), cos(k*sigma*x_2))  for k in range(1, self.i+1)])



# In[514]:


class BERR(object):
    def __init__(self, lmbda=0.1, sigma=0.5, basisExpanfunc ="poly", order_i = 1):
        self.lmbda = lmbda
        self.sigma = sigma
        self.i = order_i
        if (basisExpanfunc == "poly"):
            self.basisExpanfunc = self.basisExpansPoly
        else:
            self.basisExpanfunc = self.basisExpansTrigo

    def fit(self, X, Y):
        X = X.reshape(X.shape[0], 1)
        Y = Y.reshape(Y.shape[0], 1)
        train_phi_X = np.apply_along_axis(self.basisExpanfunc, 1, X)
        k_arr = np.dot(train_phi_X, train_phi_X.T)

        lambda_dot_i = self.lmbda*np.identity(train_phi_X.shape[0], dtype=np.float)
        self.W = np.dot(np.dot(np.linalg.inv(np.add(k_arr, lambda_dot_i)), train_phi_X).T, Y)

    def predict(self, X):
        X = X.reshape(X.shape[0], 1)
        test_phi_X = np.apply_along_axis(self.basisExpanfunc, 1, X)
        return np.dot(test_phi_X, self.W)

    def fit2(self, X, Y):
        # basis expansion with sklearn ridge regression
        X = X.reshape(X.shape[0], 1)
        Y = Y.reshape(Y.shape[0], 1)
        # compute phi along X matrix
        train_phi_X = np.apply_along_axis(self.basisExpanfunc, 1, X)

        self.clf = Ridge(alpha=self.lmbda)
        self.clf.fit(train_phi_X, Y)

    def predict2(self, X):
        X = X.reshape(X.shape[0], 1)
        test_phi_X = np.apply_along_axis(self.basisExpanfunc, 1, X)
        return self.clf.predict(test_phi_X)

    def get_params(self, deep=True):
        if self.basisExpanfunc == self.basisExpansPoly:
            basisExpanfunc = "poly"
        else:
            basisExpanfunc = "trigo"
        return {"lmbda": self.lmbda, "sigma": self.sigma, "basisExpanfunc": basisExpanfunc, "order_i": self.i }

    def set_params(self, lmbda=0.1):
        self.lmbda = lmbda
        return self

    def basisExpansPoly(self, x):
        # phi(x) = [1, x, x^2, ...., x^i]

        if (self.i == 1):
            phi = [1, x[0]]
        elif (self.i == 2):
            phi = [1, math.sqrt(2)*x[0], pow(x[0],2)]
        elif(self.i == 4):
            phi = [1, 2*x[0], math.sqrt(6)*pow(x[0],2), 2*pow(x[0],3), pow(x[0],4)]
        elif (self.i == 6):
            phi = [1, math.sqrt(6)*x[0], math.sqrt(15)*pow(x[0],2), math.sqrt(20)*pow(x[0],3), math.sqrt(15)*pow(x[0],4), math.sqrt(6)*pow(x[0],5), pow(x[0],6)]
        else:
            phi = []
            for j in range(0, self.i+1):
                phi.append(pow(x[0], j))

        return phi

    def basisExpansTrigo(self, x):
        #phi(x) = [1, sinδx, cosδx, sin2δx, cos2δx, ..., siniδx, cosiδx]
        phi = [1]
        sigma = self.sigma
        for j in range(1, self.i+1):
            phi.append(sin(j*sigma*x[0]))
            phi.append(cos(j*sigma*x[0]))
        return phi

# In[516]:


def evaluate_sample():
    train_x, train_y, test_x  = read_creditcard_data()
#     print('Train=', train_x.shape)
#     print('Test=', test_x.shape)

    kfoldLst = [8]
    alpha_lst = [1, 0.0001]
    gamma_lst = [None, 1, 0.001]
    kernel_lst = ["rbf", "polynomial", "linear"]

    mse_smallest = float('inf')
    for kfold in kfoldLst:
        for alpha in alpha_lst:
            for gamma in gamma_lst:
                for kernel in kernel_lst:
                    clf = KernelRidge(alpha=alpha, gamma = gamma, degree=3, kernel=kernel)
                    # Do cross validation and get mean MSE
                    mseLst = cross_val_score(clf,train_x, train_y, cv=kfold, scoring="neg_mean_squared_error")
                    mse_mean =  -1*np.mean(mseLst)  # find mean MSE and time -1 since cross_val_score return negative result
                    print ("Kfold:", kfold,"Alpha:", alpha," Gamma:", gamma," Kernel:", kernel," mseError:",  mse_mean)
                    # To keep best_hyperparams
                    if mse_mean < mse_smallest:
                        mse_smallest = mse_mean
                        best_hyperparams = clf.get_params()
                        best_kfold = kfold

    print ("best_hyperparams:", best_hyperparams, "mseError:", mse_smallest, "Kfold:", best_kfold)

    #The model with lowest estimated out of sample error, train it using the full training set
    clf = KernelRidge(alpha=best_hyperparams['alpha'], gamma = best_hyperparams['gamma'], degree=3, kernel=best_hyperparams['kernel'])
    clf.fit(train_x, train_y)
    print(clf)
    predicted_y = clf.predict(test_x)

    file_name = '../Predictions/CreditCard/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name, True)

# In[518]:


def find_best_model():
    train_x, train_y, test_x  = read_creditcard_data()
#     print('Train=', train_x.shape)
#     print('Test=', test_x.shape)

    kfoldLst = [3,5,8]
    alpha_lst = [0.0001, 0.001, 0.01, 1, 10]
    gamma_lst = [None, 0.0001, 0.001, 0.01, 1, 10]
    kernel_lst = [ 'rbf', 'polynomial', 'sigmoid', 'laplacian']

    mse_smallest = float('inf')
    for kfold in kfoldLst:
        for alpha in alpha_lst:
            for gamma in gamma_lst:
                for kernel in kernel_lst:
                    clf = KernelRidge(alpha=alpha, gamma = gamma, degree=3, kernel=kernel)
                    # Do cross validation and get mean MSE
                    mseLst = cross_val_score(clf,train_x, train_y, cv=kfold, scoring="neg_mean_squared_error")
                    mse_mean =  -1*np.mean(mseLst)  # find mean MSE and time -1 since cross_val_score return negative result
                    print ("Kfold:", kfold,"Alpha:", alpha," Gamma:", gamma," Kernel:", kernel," mseError:",  mse_mean)
                    # To keep best_hyperparams
                    if mse_mean < mse_smallest:
                        mse_smallest = mse_mean
                        best_hyperparams = clf.get_params()
                        best_kfold = kfold

    print ("best_hyperparams:", best_hyperparams, "mseError:", mse_smallest, "Kfold:", best_kfold)

    #The model with lowest estimated out of sample error, train it using the full training set
    clf = KernelRidge(alpha=best_hyperparams['alpha'], gamma = best_hyperparams['gamma'], degree=3, kernel=best_hyperparams['kernel'])
    clf.fit(train_x, train_y)
    print(clf)
    predicted_y = clf.predict(test_x)

    file_name = '../Predictions/CreditCard/best_2.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name, True)

# In[520]:


def main():
    evaluate_sample()
    find_best_model()
if __name__ == "__main__":
    main()
