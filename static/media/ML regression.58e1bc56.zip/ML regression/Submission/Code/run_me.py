
# coding: utf-8
# Import python modules
import matplotlib.pyplot as plt
import numpy as np
import kaggle
import time
import math

# Sklearn libraries
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso

# Read in train and test data
def read_data_power_plant():
	print('Reading power plant dataset ...')
	train_x = np.loadtxt('../../Data/PowerOutput/data_train.txt')
	train_y = np.loadtxt('../../Data/PowerOutput/labels_train.txt')
	test_x = np.loadtxt('../../Data/PowerOutput/data_test.txt')

	return (train_x, train_y, test_x)

def read_data_localization_indoors():
	print('Reading indoor localization dataset ...')
	train_x = np.loadtxt('../../Data/IndoorLocalization/data_train.txt')
	train_y = np.loadtxt('../../Data/IndoorLocalization/labels_train.txt')
	test_x = np.loadtxt('../../Data/IndoorLocalization/data_test.txt')

	return (train_x, train_y, test_x)

# Compute MAE
def compute_error(y_hat, y):
	# mean absolute error
	return np.abs(y_hat - y).mean()

############################################################################


############################################################################
#                            DecisionTreeRegressor                         #
############################################################################

def decisionTreeRegressor_test(max_depths, train_x, train_y, test_x):
    """Using 5-fold cross-validation, and Decision tree regression
    estimate the output of sample error for each model. It will test all the given max depths

    Args:
        max_depths (int array): The decision trees using the maximum depths.
        train_x (numpy.array): Training data set.
        train_y (numpy.array): Training data set.
        test_x (numpy.array): Test data set.

    """

    kf = KFold(n_splits=5) # Define the split - into 5 folds
    kf.get_n_splits(train_x) # returns the number of splitting iterations in the cross-validator
    print(kf) # display KFold's properties

    error_y = np.array([])  # To store the error value of each model
    time_each_model = np.array([]) # To store the time used in each model

    # loop cross-validation for each depth from max_depths
    for depth in max_depths:
        print("test with max depth:", depth )
        start = time.time()

        for train_index, test_index in kf.split(train_x, train_y ):
#         print("TRAIN:", train_index, "TEST:", test_index)
            X_train, X_test = train_x[train_index], train_x[test_index]
            y_train, y_test = train_y[train_index], train_y[test_index]

            #Decision Tree
            clf = DecisionTreeRegressor(max_depth=depth) # create a decision tree with max_depth is depth
            clf = clf.fit(X_train, y_train)
            error_y = np.append(error_y,compute_error(clf.predict(X_test),y_test)) # compute error and store in error_y

        end = time.time()
        elapsed = end - start
        time_each_model = np.append(time_each_model,elapsed) # add avg time for each model into array time_each_model
        print("time:", elapsed, "milliseconds")
        print("mean error:", error_y.mean(), "\n")
        error_y = np.array([])

    # Plot the results
    plt.figure()
    plt.scatter(max_depths, time_each_model, s=20, edgecolor="black",
            c="darkorange", label="data")
    plt.xlabel("maximum depths")
    plt.ylabel("time (in milliseconds)")
    plt.title("Decision Tree Regression")
    plt.legend()
    plt.show()

############################################################################
#        the power plant dataset train 5 different decision trees          #
#          using the following maximum depths {3, 6, 9, 12, 15}            #
############################################################################
def question_1_b():
    # load data power plant
    train_x, train_y, test_x = read_data_power_plant()

    max_depths =[3,6,9,12,15] # training max_depth
    decisionTreeRegressor_test(max_depths,train_x, train_y, test_x)

    # For upload the predicted result to kaggle
    # The model with lowest estimated out of sample error is when max_depth=9,
    # train it with the full training set
    clf = DecisionTreeRegressor(max_depth=9)
    clf = clf.fit(train_x, train_y)
    predicted_y = clf.predict(test_x)

    # Output file location
    file_name = '../Predictions/PowerOutput/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

############################################################################
#   the localization indoors dataset train 5 different decision trees      #
#         using the following maximum depths {20, 25, 30, 35, 40}          #
############################################################################
def question_1_c():
    # load data localization indoors
    train_x, train_y, test_x = read_data_localization_indoors()

    max_depths = [20, 25, 30, 35, 40] # training max_depth
    decisionTreeRegressor_test(max_depths, train_x, train_y, test_x)

    # For upload the predicted results to Kaggle
    # The model with lowest estimated out of sample error is when max_depth=40,
    # train it with the full training set
    clf = DecisionTreeRegressor(max_depth=40)
    clf = clf.fit(train_x, train_y)
    predicted_y = clf.predict(test_x)

    # Output file location
    file_name = '../Predictions/IndoorLocalization/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

############################################################################
#                           KNeighborsRegressor                            #
############################################################################
def KNeighborsRegressor_test(n_neighbors, train_x, train_y, test_x):
    """Using 5-fold cross-validation, and KNeighbors regression
    estimate the output of sample error for each model. It will test all the given n neighbors.

    Args:
        n_neighbors (int array): The KNeighbors regression using n neighbors.
        train_x (numpy.array): Training data set.
        train_y (numpy.array): Training data set.
        test_x (numpy.array): Test data set.

    """
    kf = KFold(n_splits=5) # Define the split - into 5 folds
    kf.get_n_splits(train_x) # returns the number of splitting iterations in the cross-validator
    print(kf) # display KFold's properties

    error_y = np.array([]) # To store the error value of each model
    time_each_model = np.array([]) # To store the time used in each model

    for n_neighbor in n_neighbors:
        print("test with n_neighbor:", n_neighbor )
        start = time.time()
        #cross-validation
        for train_index, test_index in kf.split(train_x, train_y ):
            X_train, X_test = train_x[train_index], train_x[test_index]
            y_train, y_test = train_y[train_index], train_y[test_index]
            # KNeighbors
            neigh = KNeighborsRegressor(n_neighbors=n_neighbor)
            neigh = neigh.fit(X_train, y_train)
            error_y = np.append(error_y,compute_error(neigh.predict(X_test),y_test))

        end = time.time()
        elapsed = end - start
        time_each_model = np.append(time_each_model,elapsed)

        print("time:", elapsed, "milliseconds")
        print("mean error:", error_y.mean(), "\n")

        error_y = np.array([])

    # Plot the results
    plt.figure()
    plt.scatter(n_neighbors, time_each_model, s=20, edgecolor="black",
            c="darkorange", label="data")
    plt.xlabel("n_neighbors")
    plt.ylabel("time (in milliseconds)")
    plt.title("Nearest Neighbors Regression")
    plt.legend()
    plt.show()
############################################################################
#        the power plant dataset train 5 different nearest neighbors       #
#   regressors using the following number of neighbors {3, 5, 10, 20, 25}  #
############################################################################
def question_2_a():
    # load data power plant
    train_x, train_y, test_x = read_data_power_plant()

    n_neighbors = [3, 5, 10, 20, 25]
    KNeighborsRegressor_test(n_neighbors, train_x, train_y, test_x)

    # The model with lowest estimated out of sample error when n_neighbors=3, train it with the full training set
    neigh = KNeighborsRegressor(n_neighbors=3)
    neigh = neigh.fit(train_x, train_y)
    predicted_y = neigh.predict(test_x)

    # Output file location
    file_name = '../Predictions/PowerOutput/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

############################################################################
#   the  localization indoors dataset train 5 different nearest neighbors  #
#   regressors using the following number of neighbors {3, 5, 10, 20, 25}  #
############################################################################
def question_2_b():
    # load data localization indoors
    train_x, train_y, test_x = read_data_localization_indoors()

    n_neighbors = [3, 5, 10, 20, 25]
    KNeighborsRegressor_test(n_neighbors, train_x, train_y, test_x)

    # The model with lowest estimated out of sample error is when n_neighbors=3,
    # train it with the full training set
    neigh = KNeighborsRegressor(n_neighbors=3)
    neigh = neigh.fit(train_x, train_y)
    predicted_y = neigh.predict(test_x)

    # Output file location
    file_name = '../Predictions/IndoorLocalization/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

############################################################################
#                        Ridge and Lesso Regressor                         #
############################################################################
def RidgeRegression_test(alphas, train_x, train_y, test_x):
    """Using 5-fold cross-validation, and Ridge Regression
    estimate the output of sample error for each model. It will test all the given 10^alpha.

    Args:
        alphas (int array): The Ridge regression using the regularization constants α.
        train_x (numpy.array): Training data set.
        train_y (numpy.array): Training data set.
        test_x (numpy.array): Test data set.

    """
    kf = KFold(n_splits=5) # Define the split - into 5 folds
    kf.get_n_splits(train_x) # returns the number of splitting iterations in the cross-validator
    print(kf) # display KFold's properties

    error_y = np.array([]) # To store the error value of each model
    time_each_model = np.array([])  # To store the time used in each model

    for alpha in alphas:
        alpha = math.pow(10,alpha)
        print("test with alpha:", alpha )
        start = time.time()
        #cross-validation
        for train_index, test_index in kf.split(train_x, train_y ):
            X_train, X_test = train_x[train_index], train_x[test_index]
            y_train, y_test = train_y[train_index], train_y[test_index]

            # Ridge model
            ridgeReg = Ridge(alpha=alpha) # set alpha is ten power of alpha ex. 10^alpha
            ridgeReg = ridgeReg.fit(X_train,y_train)
            error_y = np.append(error_y,compute_error(ridgeReg.predict(X_test),y_test))

        end = time.time()
        elapsed = end - start
        time_each_model = np.append(time_each_model,elapsed)
        print("time:", elapsed, "milliseconds")
        print("mean error:", error_y.mean(), "\n")
        error_y = np.array([])

    print(time_each_model)

    # Plot the results
    plt.figure()
    plt.scatter(alphas, time_each_model, s=20, edgecolor="black",
            c="darkorange", label="data")
    plt.xlabel("alpha [$10^{x}]$")
    plt.ylabel("time (in milliseconds)")
    plt.title("Ridge Regression")
    plt.legend()
    plt.show()

def LassoRegression_test(alphas, train_x, train_y, test_x):
    """Using 5-fold cross-validation, and Lesso Regression
    estimate the output of sample error for each model. It will test all the given 10^alpha.

    Args:
        alphas (int array): The Ridge regression using the regularization constants α.
        train_x (numpy.array): Training data set.
        train_y (numpy.array): Training data set.
        test_x (numpy.array): Test data set.

    """
    kf = KFold(n_splits=5) # Define the split - into 5 folds
    kf.get_n_splits(train_x) # returns the number of splitting iterations in the cross-validator
    print(kf) # display KFold's properties

    error_y = np.array([]) # To store the error value of each model
    time_each_model = np.array([]) # To store the time used in each model

    for alpha in alphas:
        alpha = math.pow(10,alpha) # set alpha is ten power of alpha ex. 10^alpha
        print("test with alpha:", alpha )

        start = time.time()
        #cross-validation
        for train_index, test_index in kf.split(train_x, train_y ):
            X_train, X_test = train_x[train_index], train_x[test_index]
            y_train, y_test = train_y[train_index], train_y[test_index]

            # Lesso model
            lassoReg = Lasso(alpha=alpha)
            lassoReg = lassoReg.fit(X_train,y_train)
            error_y = np.append(error_y,compute_error(lassoReg.predict(X_test),y_test))

        end = time.time()
        elapsed = end - start
        time_each_model = np.append(time_each_model,elapsed)
        print("time:", elapsed, "milliseconds")
        print("mean error:", error_y.mean(), "\n")
        error_y = np.array([])

    print(time_each_model)

    # Plot the results
    plt.figure()
    plt.scatter(alphas, time_each_model, s=20, edgecolor="black",
            c="darkorange", label="data")
    plt.xlabel("alpha [$10^{x}$]")
    plt.ylabel("time (in milliseconds)")
    plt.title("Lasso Regression")
    plt.legend()
    plt.show()

############################################################################
#       the  power plant dataset train 5 different a constant alphas       #
#  using the following number of alphas {10^-6, 10^-4, 10^-2, 10^0, 10^1}  #
############################################################################
def question_4_b():
    train_x, train_y, test_x = read_data_power_plant()
    ten_power_alphas = [-6, -4, -2, 0, 1] # To store the ten power for alphas ex. 1 = 10^1

    # Run RidgeRegression_test and LassoRegression_test which handling power plant dataset
    RidgeRegression_test(ten_power_alphas, train_x, train_y, test_x)
    LassoRegression_test(ten_power_alphas, train_x, train_y, test_x)

    # The model with lowest estimated out of sample error is when alpha=0.000001,
    # train it with the full training set
    ridgeReg = Ridge(alpha=0.000001)
    ridgeReg = ridgeReg.fit(train_x,train_y)
    predicted_y = ridgeReg.predict(test_x)

    # Output file location
    file_name = '../Predictions/PowerOutput/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

############################################################################
# the  localization indoors dataset train 4 different a constant alphas    #
#     using the following number of alphas { 10^-4, 10^-2, 10^0, 10^1}     #
############################################################################
def question_4_c():
    train_x, train_y, test_x = read_data_localization_indoors()
    ten_power_alphas = [-4, -2, 0, 1] # To store 10^element s in the array

    RidgeRegression_test(ten_power_alphas, train_x, train_y, test_x)
    LassoRegression_test(ten_power_alphas, train_x, train_y, test_x)

    # The model with lowest estimated out of sample error is when alpha=10^-2 and using Lesso model,
    # train it with the full training set

    lassoReg = Lasso(alpha=0.01)
    lassoReg = lassoReg.fit(train_x,train_y)
    predicted_y = lassoReg.predict(test_x)

    # Output file location
    file_name = '../Predictions/IndoorLocalization/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

############################################################################
#                            Kaggle Competition                            #
############################################################################
def BestDecisionTree(max_depths, kfolds,train_x, train_y,test_x):
    """Using K-fold cross-validation, and Decision Tree regression
    estimate the output of sample error for each model. It will test all the given max_depths and kfolds .

    Args:
        max_depths (int array): The Decision Tree regression using d depths.
        kfolds (int array): The K-fold cross-validation using k folds
        train_x (numpy.array): Training data set.
        train_y (numpy.array): Training data set.
        test_x (numpy.array): Test data set.
    """
    error_y = np.array([]) # To store the mean error for each model
    # loop through the kfolds for cross-validation
    for k in kfolds:
        kf = KFold(n_splits=k) # Define the split - into 5 folds
        kf.get_n_splits(train_x)
        print(kf)

        # loop through Hyperparameter range
        for d in max_depths:
            print("kfold: ", k, " depth: ", d)
            mean_error = np.array([])  # To store the error value for each K-fold cross-validation
            for train_index, test_index in kf.split(train_x, train_y):
                X_train, X_test = train_x[train_index], train_x[test_index]
                y_train, y_test = train_y[train_index], train_y[test_index]

                # Desicion Tree
                clf = DecisionTreeRegressor(max_depth=d, min_samples_leaf=3) # Create decision tree wint max depth d
                clf = clf.fit(X_train, y_train)
                mean_error = np.append(mean_error,compute_error(clf.predict(X_test),y_test))
                print(compute_error(clf.predict(X_test),y_test))

            error_y = np.append(error_y,mean_error.mean())
            print("Mean error: ",mean_error.mean())

    print('min',error_y.min()) # Print the lowest min error

def question_5_a():
    train_x, train_y, test_x = read_data_power_plant()

    depths = range(5,12) # depths range from 5 to 12
    kfolds = range(5,12) # kfold range from 5 to 12

    BestDecisionTree(depths,kfolds,train_x, train_y, test_x)

    clf = DecisionTreeRegressor(max_depth=14, min_samples_leaf=8) # Create decision tree wint max depth d
    clf = clf.fit(train_x, train_y)
    predicted_y = clf.predict(test_x)
    # Output file location
    file_name = '../Predictions/PowerOutput/best.csv'
    # Writing output in Kaggle format
    print('Writing output to ', file_name)
    kaggle.kaggleize(predicted_y, file_name)

def BestKNeighborsRegressor(n_neighbors, kfolds,train_x, train_y,test_x):
    """Using K-fold cross-validation, and KNeighbors Regressor
    estimate the output of sample error for each model. It will test all the given n_neighbors and kfolds.

    Args:
        n_neighbors (int array): The KNN  regression using k neighbors.
        kfolds (int array): The K-fold cross-validation using k folds.
        train_x (numpy.array): Training data set.
        train_y (numpy.array): Training data set.
        test_x (numpy.array): Test data set.
    """
    error_y = np.array([])
    count = 0 # To get the best cross-validation
    for k in kfolds:
        kf = KFold(n_splits=k, shuffle=False) # Define the split - into 5 folds
        kf.get_n_splits(train_x)
        print(kf)

        for n in n_neighbors:
            print("kfold: ", k, " n_neighbors: ", n)
            mean_error = np.array([])
            for train_index, test_index in kf.split(train_x, train_y):
                X_train, X_test = train_x[train_index], train_x[test_index]
                y_train, y_test = train_y[train_index], train_y[test_index]

                # KNeighbors
                neigh = KNeighborsRegressor(n_neighbors=n)
                neigh = neigh.fit(X_train, y_train)
                mean_error = np.append(mean_error,compute_error(neigh.predict(X_test),y_test))
                print(compute_error(neigh.predict(X_test),y_test))
                count=count+1
                if count is 4:
                    predicted_y = neigh.predict(test_x)
                    # Output file location
                    file_name = '../Predictions/IndoorLocalization/best.csv'
                    # Writing output in Kaggle format
                    print('Writing output to ', file_name)
                    kaggle.kaggleize(predicted_y, file_name)

            error_y = np.append(error_y,mean_error.mean())
            print(mean_error.mean())

    print('min',error_y.min()) # Print the lowerst error

def question_5_b():
    train_x, train_y, test_x = read_data_localization_indoors()

    n_neighbors=[1]
    kfolds= [21]

    BestKNeighborsRegressor(n_neighbors,kfolds,train_x, train_y, test_x)

def main():
    print("question_1_b")
    question_1_b()
    print("question_1_c")
    question_1_c()
    print("question_2_a")
    question_2_a()
    print("question_2_b")
    question_2_b()
    print("question_4_b")
    question_4_b()
    print("question_4_c")
    question_4_c()
    print("question_5_a")
    question_5_a()
    print("question_5_b")
    question_5_b()

if __name__ == "__main__":
    main()
